int Z;

void f()
{
        int a, b, c;
        a = Z;
        if (a < 10) {
                b = 5;
                c = 17;
        } else {
                b = 6;
                c = 20;
                if (a == 0) {
                        c = 0;
                }
        }
        Z = b * 10 + c;
}


2.o:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <f>:
   0:   55                      push   %rbp
   1:   48 89 e5                mov    %rsp,%rbp
   4:   48 83 ec 10             sub    $0x10,%rsp
   8:   48 8d 05 00 00 00 00    lea    0x0(%rip),%rax        # f <f+0xf>
                        b: R_X86_64_PC32        Z-0x4
   f:   8b 00                   mov    (%rax),%eax
  11:   89 45 f4                mov    %eax,-0xc(%rbp)
  14:   83 7d f4 09             cmpl   $0x9,-0xc(%rbp)
  18:   7f 10                   jg     2a <f+0x2a>
  1a:   c7 45 fc 05 00 00 00    movl   $0x5,-0x4(%rbp)
  21:   c7 45 f8 11 00 00 00    movl   $0x11,-0x8(%rbp)
  28:   eb 1b                   jmp    45 <f+0x45>
  2a:   c7 45 fc 06 00 00 00    movl   $0x6,-0x4(%rbp)
  31:   c7 45 f8 14 00 00 00    movl   $0x14,-0x8(%rbp)
  38:   83 7d f4 00             cmpl   $0x0,-0xc(%rbp)
  3c:   75 07                   jne    45 <f+0x45>
  3e:   c7 45 f8 00 00 00 00    movl   $0x0,-0x8(%rbp)
  45:   8b 55 fc                mov    -0x4(%rbp),%edx
  48:   89 d0                   mov    %edx,%eax
  4a:   c1 e0 02                shl    $0x2,%eax
  4d:   01 d0                   add    %edx,%eax
  4f:   01 c0                   add    %eax,%eax
  51:   89 c2                   mov    %eax,%edx
  53:   8b 45 f8                mov    -0x8(%rbp),%eax
  56:   01 c2                   add    %eax,%edx
  58:   48 8d 05 00 00 00 00    lea    0x0(%rip),%rax        # 5f <f+0x5f>
                        5b: R_X86_64_PC32       Z-0x4
  5f:   89 10                   mov    %edx,(%rax)
  61:   90                      nop
  62:   48 83 c4 10             add    $0x10,%rsp
  66:   5d                      pop    %rbp
  67:   c3                      retq
  68:   90                      nop
  69:   90                      nop
  6a:   90                      nop
  6b:   90                      nop
  6c:   90                      nop
  6d:   90                      nop
  6e:   90                      nop
  6f:   90                      nop

