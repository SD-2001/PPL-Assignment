int AddTwo(int a)
{
    a = a + 2;
    return a;
}

int main()
{
    int x = 3;
    x = AddTwo(x);
    return x;
}


B1.o:     file format pe-x86-64


Disassembly of section .text:

0000000000000000 <AddTwo>:
   0:   55                      push   %rbp
   1:   48 89 e5                mov    %rsp,%rbp
   4:   89 4d 10                mov    %ecx,0x10(%rbp)
   7:   83 45 10 02             addl   $0x2,0x10(%rbp)
   b:   8b 45 10                mov    0x10(%rbp),%eax
   e:   5d                      pop    %rbp
   f:   c3                      retq

0000000000000010 <main>:
  10:   55                      push   %rbp
  11:   48 89 e5                mov    %rsp,%rbp
  14:   48 83 ec 30             sub    $0x30,%rsp
  18:   e8 00 00 00 00          callq  1d <main+0xd>
                        19: R_X86_64_PC32       __main
  1d:   c7 45 fc 03 00 00 00    movl   $0x3,-0x4(%rbp)
  24:   8b 45 fc                mov    -0x4(%rbp),%eax
  27:   89 c1                   mov    %eax,%ecx
  29:   e8 d2 ff ff ff          callq  0 <AddTwo>
  2e:   89 45 fc                mov    %eax,-0x4(%rbp)
  31:   8b 45 fc                mov    -0x4(%rbp),%eax
  34:   48 83 c4 30             add    $0x30,%rsp
  38:   5d                      pop    %rbp
  39:   c3                      retq
  3a:   90                      nop
  3b:   90                      nop
  3c:   90                      nop
  3d:   90                      nop
  3e:   90                      nop
  3f:   90                      nop


