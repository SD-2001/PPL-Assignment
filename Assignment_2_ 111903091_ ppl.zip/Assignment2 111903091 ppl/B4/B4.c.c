int main()
{
    int a, b, c;
    b = (a + c + b) * (c + a);
    return b;
}


Disassembly of section .text:

0000000000000000 <main>:
   0:   55                      push   %rbp
   1:   48 89 e5                mov    %rsp,%rbp
   4:   48 83 ec 30             sub    $0x30,%rsp
   8:   e8 00 00 00 00          callq  d <main+0xd>
                        9: R_X86_64_PC32        __main
   d:   8b 55 fc                mov    -0x4(%rbp),%edx
  10:   8b 45 f8                mov    -0x8(%rbp),%eax
  13:   01 c2                   add    %eax,%edx
  15:   8b 45 f4                mov    -0xc(%rbp),%eax
  18:   8d 0c 02                lea    (%rdx,%rax,1),%ecx
  1b:   8b 55 f8                mov    -0x8(%rbp),%edx
  1e:   8b 45 fc                mov    -0x4(%rbp),%eax
  21:   01 d0                   add    %edx,%eax
  23:   0f af c1                imul   %ecx,%eax
  26:   89 45 f4                mov    %eax,-0xc(%rbp)
  29:   8b 45 f4                mov    -0xc(%rbp),%eax
  2c:   48 83 c4 30             add    $0x30,%rsp
  30:   5d                      pop    %rbp
  31:   c3                      retq
  32:   90                      nop
  33:   90                      nop
  34:   90                      nop
  35:   90                      nop
  36:   90                      nop
  37:   90                      nop
  38:   90                      nop
  39:   90                      nop
  3a:   90                      nop
  3b:   90                      nop
  3c:   90                      nop
  3d:   90                      nop
  3e:   90                      nop
  3f:   90                      nop

